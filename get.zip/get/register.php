<?php
if($_GET['name']=="" || $_GET['email']==""){
    exit ('please go back to previous page and fill the form properly');
}
elseif(isset($_GET['submit'])){
    $name=$_GET['name'];
    $email=$_GET['email'];
    echo $name;
    echo "<br>";
    echo $email;
}else{
    echo "Not Authorised";
}
?>